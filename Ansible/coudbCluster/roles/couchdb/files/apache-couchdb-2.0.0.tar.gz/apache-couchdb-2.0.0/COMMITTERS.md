Apache CouchDB COMMITTERS
=========================

Committers are given a binding vote in certain project decisions, as well as
write access to public project infrastructure. The following people were
elected as a committer in recognition of their commitment to the project. We
mean this in the sense of being loyal to the project and its interests.

 * Damien Katz <damien@apache.org>
 * Jan Lehnardt <jan@apache.org>
 * Noah Slater <nslater@apache.org>
 * Christopher Lenz <cmlenz@apache.org>
 * J. Chris Anderson <jchris@apache.org>
 * Paul Joseph Davis <davisp@apache.org>
 * Adam Kocoloski <kocolosk@apache.org>
 * Jason Davies <jasondavies@apache.org>
 * Mark Hammond <mhammond@apache.org>
 * Benoît Chesneau <benoitc@apache.org>
 * Filipe Manana <fdmanana@apache.org>
 * Robert Newson <rnewson@apache.org>
 * Randall Leeds <randall@apache.org>
 * Bob Dionne <bitdiddle@apache.org>
 * Dave Cottlehuber <dch@apache.org>
 * Jason Smith <jhs@apache.org>
 * Joan Touzet <wohali@apache.org>
 * Dale Harvey <dale@apache.org>
 * Dirkjan Ochtman <djc@apache.org>
 * Alexander Shorin <kxepal@apache.org>
 * Garren Smith <garren@apache.org>
 * Sue Lockwood <deathbear@apache.org>
 * Andy Wenk <andywenk@apache.org>
 * Klaus Trainer <klaus_trainer@apache.org>
 * Benjamin Young <bigbluehat@apache.org>
 * Robert Kowalski <robertkowalski@apache.org>
 * Max Thayer <garbados@apache.org>
 * Gianugo Rabellino <gianugo@apache.org>
 * Jenn Schiffer <jenn@apache.org>
 * Lena Reinhard <lena@apache.org>
 * Simon Metson <metson@apache.org>
 * Mike Wallace <mikewallace@apache.org>
 * Nick North <nicknorth@apache.org>
 * Ryan Ramage <ryanramage@apache.org>
 * Sebastian Rothbucher <sebastianro@apache.org>
 * Ted Leung <twl@apache.org>
 * Wendall Cada <wendallc@apache.org>
 * Benjamin Bastian <bbastian@apache.org>
 * Ben Keen <benkeen@apache.org>
 * Maria Andersson <mia@apache.org>
 * Michelle Phung <michellep@apache.org>
 * Clemens Stolle <klaemo@apache.org>

For a list of other credits see the `THANKS` file.
